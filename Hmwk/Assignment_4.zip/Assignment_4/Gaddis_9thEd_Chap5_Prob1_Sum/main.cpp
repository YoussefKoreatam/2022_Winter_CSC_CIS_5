/* 
 * File:   main.cpp
 * Author: Youssef Koreatam
 * Created on January 24, 2022,
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int num,
        total = 0;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    cin >> num;
    for (int i = num; i > 0; i--){
        total += i;
        ;
    }
    //Display the outputs
    cout << "Sum = " << total;
    //Exit stage right or left!
    return 0;
}