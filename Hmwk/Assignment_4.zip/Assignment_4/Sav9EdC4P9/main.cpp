/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes
float lrgtwo(float, float);

float lrgthr(float, float, float);
//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    float num1,
          num2,
          num3,
          lrg2,
          lrg3,
          Lrgest,
          Largest;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    cout << "Enter first number:" << endl << endl;
    cin >> num1;
    cout << "Enter Second number:" << endl << endl;
    cin >> num2;
    cout << "Enter third number:" << endl << endl;
    cin >> num3;
    lrg2 = lrgtwo(num1, num2);
    lrg3 = lrgthr(num1, num2, num3);
    //Display the outputs
    cout << "Largest number from two parameter function:" << endl << lrg2 << endl << endl;
    cout << "Largest number from three parameter function:" << endl << lrg3 << endl;
    //Exit stage right or left!
    return 0;
}
float lrgtwo(float num1, float num2){
    float Largest;
    Largest =(num1 > num2) ? num1 : num2;
    return Largest;
}
float lrgthr(float num1, float num2, float num3){
    float Lrgest;
      if (num1 > num2 && num1 > num3){
        Lrgest = num1;
    } else if (num2 > num1 && num2 > num3){
        Lrgest = num2;
        
    } else {
            Lrgest = num3;
        }
    return Lrgest;
    
}
