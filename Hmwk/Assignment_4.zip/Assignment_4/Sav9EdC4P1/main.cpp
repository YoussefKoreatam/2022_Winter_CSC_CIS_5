/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;
#include <iomanip>

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int liters,
        miles;
    bool contin = true;
    string again;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    while (contin){
        cout << "Enter number of liters of gasoline:" << endl << endl;
        cin >> liters;
        cout << "Enter number of miles traveled:" << endl << endl;
        cin >> miles;
        cout << "miles per gallon:" << endl;
        cout << fixed << setprecision(2);
        cout << static_cast<float>(miles / (liters * 0.264179)) << endl;
        cout << "Again:" << endl;
        cin >> again;
        if (again == "n"){
            contin = false;
        } else {
            cout << endl;
        }
        
    }
    //Exit stage right or left!
    return 0;
}