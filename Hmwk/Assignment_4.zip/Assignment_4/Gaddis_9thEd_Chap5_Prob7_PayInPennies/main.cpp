/* 
 * File:   main.cpp
 * Author: Youssef Koreatam
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  calculates how much a person would earn over a period of time
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;
#include <math.h>
#include <iomanip>

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int day;
    //Initialize or input i.e. set variable values

    //Map inputs -> outputs
    cin >> day;
    if (day >= 1){
    //Display the outputs
    
    cout << fixed << setprecision(2);
    cout << "Pay = $" << setw(3) << ((pow(2,day) - 1) * 0.01);
    }
    //Exit stage right or left!
    return 0;
}