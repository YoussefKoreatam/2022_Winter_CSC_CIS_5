/* 
 * File:   main.cpp
 * Author: Youssef Koreatam
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int side;
    char let;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    cin >> side >> let;
    //Display the outputs
    if (side <= 15 && side >= 1){
    for (int i = side; i > 0; i--){
    for (int i = side; i > 0; i--){
        cout << let;
    } if (i > 1){
        cout << endl;
    }
    }
    } 
    
    //Exit stage right or left!
    return 0;
}