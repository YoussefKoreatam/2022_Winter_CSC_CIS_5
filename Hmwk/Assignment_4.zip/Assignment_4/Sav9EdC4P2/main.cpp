/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;
#include <iomanip>

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int liters1,
        miles1,
        liters2,
        miles2;
    float car1,
          car2;
    bool contin = true;
    string again;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    while (contin){
        cout << "Car 1" << endl;
        cout << "Enter number of liters of gasoline:" << endl;
        cin >> liters1;
        cout << "Enter number of miles traveled:" << endl;
        cin >> miles1;
        cout << fixed << setprecision(2);
        car1 = (miles1 / (liters1 * 0.264179));
        cout << "miles per gallon: " << car1 << endl << endl;
        cout << "Car 2" << endl;
        cout << "Enter number of liters of gasoline:" << endl;
        cin >> liters2;
        cout << "Enter number of miles traveled:" << endl;
        cin >> miles2;
        cout << fixed << setprecision(2);
        car2 = (miles2 / (liters2 * 0.264179));
        cout << "miles per gallon: " << car2 << endl << endl;
        if(car1 > car2){
            cout << "Car 1 ";
        } else {
            cout << "Car 2 ";
        }
        cout << "is more fuel efficient" << endl << endl;
        cout << "Again:" << endl;
        cin >> again;
        if (again == "n"){
            contin = false;
        } else {
            cout << endl;
        }
        
    }
    //Exit stage right or left!
    return 0;
}