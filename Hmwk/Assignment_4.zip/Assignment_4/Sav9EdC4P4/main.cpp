/* 
 * File:   
 * Author: 
 * Created on 
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;
#include <iomanip>
//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    bool cont = true;
    float cprice,
          oprice,
          infl;
    string again;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    while(cont){
    cout << "Enter current price:" << endl;
    cin >> cprice;
    cout << "Enter year-ago price:" << endl;
    cin >> oprice;
    infl = (cprice - oprice) / oprice * 100;
    cout << fixed << setprecision(2);
    cout << "Inflation rate: " << infl << "%" << endl << endl;
    cout << "Again:" << endl;
    cin >> again;
    if (again == "y"){
        cout << endl;
    } else {
        cont = false;
    }
    }
    //Display the outputs

    //Exit stage right or left!
    return 0;
}