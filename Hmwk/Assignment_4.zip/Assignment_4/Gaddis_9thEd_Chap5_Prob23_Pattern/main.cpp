/* 
 * File:   main.cpp
 * Author: Dr. Mark E. Lehr
 * Created on January 2, 2019, 12:36 PM
 * Purpose:  Creation of Template to be used for all
 *           future projects
 */

//System Libraries
#include <iostream>  //Input/Output Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int given;
    //Initialize or input i.e. set variable values
    
    //Map inputs -> outputs
    cin >> given;
    // for (int i = given; i > 0; i--){
    //     cout << "+" << endl;
    // }
    // 
    for (int x = 0; x < given; x++){
        int i = x + 1;
    
    while(i > 0){
        
        cout << "+";
        i -= 1;
    
        
    }
    cout << endl << endl;
    }
    for (int z = given; z > 0; z--){
        int y = z;
    
    while(y > 0){
        
        cout << "+";
        y -= 1;
    
        
    }
    if (z > 1 ){
    cout << endl << endl;
    }
        
    }
    
    //Display the outputs

    //Exit stage right or left!
    return 0;

}