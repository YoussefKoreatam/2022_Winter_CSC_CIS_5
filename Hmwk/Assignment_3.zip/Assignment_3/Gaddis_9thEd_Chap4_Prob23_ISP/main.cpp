//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution begins here
int main(int argc, char **argv)
{
    //Declare  Variables here
    char ISPkge;
    float hrs, bill, ot;

    //Initialize Variables here
    cout << "ISP Bill" << endl;
    cout << "Input Package and Hours" << endl;
    cin >> ISPkge >> hrs;

    //Map inputs/knowns to the output
    //calculate bill based on package and hours used
    switch(ISPkge){
        case 'A': bill = hrs > 10 ?  9.95 + ((hrs - 10) * 2.00) :  9.95; break;
        case 'B': bill = hrs > 20 ? 14.95 + ((hrs - 20) * 1.00) : 14.95; break;
        default: bill = 19.95;
    }


    //Display the outputs
    cout<<setprecision(2)<<fixed;
    cout<<"Bill = $"<<setw(6)<<bill;
    //Exit stage right or left!
    return 0;
}