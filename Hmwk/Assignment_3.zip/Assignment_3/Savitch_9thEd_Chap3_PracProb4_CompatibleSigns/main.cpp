#include <iostream>  //Input-Output Library
#include <iomanip>   //Format Library
#include <string>    //String Library
#include <algorithm> //Algorithm Library
using namespace std;

//Execution begins here
int main(int argc, char **argv)
{
    //Declare  Variables here
    string sign1, sign2, type1, type2;

    //Initialize Variables here
    cout << "Horoscope Program which examines compatible signs." << endl;
    cout << "Input 2 signs." << endl;
    cin >> sign1 >> sign2;

    //Map inputs/knowns to the output
    //find type of sign 1
    type1 = (sign1 == "Aries"  || sign1 == "Leo"     || sign1 == "Sagittarius")   ? "Fire" :
            (sign1 == "Taurus" || sign1 == "Virgo"   || sign1 == "Capricorn")     ? "Earth":
            (sign1 == "Gemini" || sign1 == "Libra"   || sign1 == "Aquarius")      ? "Air"  : "Water";
    //find type of sign 2
    type2 = (sign2 == "Aries"  || sign2 == "Leo"     || sign2 == "Sagittarius")   ? "Fire" :
            (sign2 == "Taurus" || sign2 == "Virgo"   || sign2 == "Capricorn")     ? "Earth":
            (sign2 == "Gemini" || sign2 == "Libra"   || sign2 == "Aquarius")      ? "Air"  : "Water";

    //Display Output
    type1 == type2
        ? cout << sign1 << " and " << sign2 << " are compatible " << type1 << " signs."
        : cout << sign1 << " and " << sign2 << " are not compatible signs.";

    //Exit the program
    return 0;
}