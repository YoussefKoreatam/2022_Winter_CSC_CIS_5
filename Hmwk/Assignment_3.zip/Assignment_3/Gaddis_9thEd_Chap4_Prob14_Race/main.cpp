#include <iostream>  //Input/Output Library
#include <string>
#include <iomanip>
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    string runnr1, 
           runnr2, 
           runnr3,
           frstN1,
           frstN2,
           frstN3;
    int runT1,
        runT2,
        runT3,
        frst,
        scnd,
        thrd;
    
    //Initialize or input i.e. set variable values
    cout << "Race Ranking Program" <<endl;
    cout << "Input 3 Runners"<<endl;
    cout << "Their names, then their times" << endl;
    cin >> runnr1 >> runT1 >> runnr2 >> runT2 >> runnr3 >> runT3;
    // //Map inputs -> outputs
    if(runT1 < 0  || runT2 < 0 || runT3 < 0){
        cout<<"Error. Run times must be greater than 0. Please try again.";
    } else {
        // First
        if (runT1 > runT2 && runT1 > runT3){
            frst = runT1;
            if (runT2 > runT3){
                scnd = runT2;
                thrd = runT3;
            } else{
                thrd = runT3;
                scnd = runT2;
            }
        } else if (runT2 >= runT1 && runT2 >= runT3){
            frst = runT2;
            if (runT1 > runT3){
                scnd = runT1;
                thrd = runT3;
            } else{
                scnd = runT3;
                thrd = runT1;
            }
        }else {
            frst = runT3;
            if (runT1 > runT2){
                scnd = runT1;
                thrd = runT2;
            } else{
                scnd = runT2;
                thrd = runT1;
                
            }
            
        }

    }
    if (frst == runT1){
        frstN1 = runnr1;
    } else if (frst == runT2){
        frstN1 = runnr2;
    } else {
        frstN1 = runnr3;
    }
    
    if (scnd == runT1){
        frstN2 = runnr1;
    } else if (scnd == runT2){
        frstN2 = runnr2;
    } else {
        frstN2 = runnr3;
    }
    
    if (thrd == runT1){
        frstN3 = runnr1;
    } else if (thrd == runT2){
        frstN3 = runnr2;
    } else {
        frstN3 = runnr3;
    }
    //Display the outputs

cout << frstN3 << "\t" << setw(3) << thrd << endl;
cout << frstN2 << "\t" << setw(3) << scnd << endl;
cout << frstN1 << "\t" << setw(3) << frst;
    //Exit stage right or left!
    return 0;
}