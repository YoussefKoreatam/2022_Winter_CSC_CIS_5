//System Libraries
#include <iostream>  //Input/Output Library
#include <iomanip>  //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int num_checks;
    
    float Start_BAL,
          Total_MC = 10,
          low_bal,
          new_bal,
          che_fee;
    
    
    
    //Initialize or input i.e. set variable values
    cout<<"Monthly Bank Fees"<<endl;
    cout<<"Input Current Bank Balance and Number of Checks"<<endl;
    cin>>Start_BAL>>num_checks;
    
    //Map inputs -> outputs
    if (Start_BAL < 400)
        low_bal = 15;
    
    
    che_fee =                       num_checks < 20 ? num_checks * 0.10 :
             (num_checks >= 20 && num_checks <= 39) ? num_checks * 0.08 :
             (num_checks >= 40 && num_checks <= 59) ? num_checks * 0.08 : num_checks * 0.04;

    new_bal = Start_BAL - (low_bal + che_fee + Total_MC);
    
    //Display the outputs
    cout<<setprecision(2)<<fixed;
    cout<<"Balance     $"<<setw(9)<<Start_BAL<<endl;
    cout<<"Check Fee   $"<<setw(9)<<che_fee<<endl;
    cout<<"Monthly Fee $"<<setw(9)<<Total_MC<<endl;
    cout<<"Low Balance $"<<setw(9)<<low_bal<<endl;
    cout<<"New Balance $"<<setw(9)<<new_bal;
    
    
    //Exit stage right or left!
    return 0;
}