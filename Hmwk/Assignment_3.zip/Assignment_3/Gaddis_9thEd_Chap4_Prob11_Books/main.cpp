#include <iostream>  //Input/Output Library
#include <iomanip>   //Format Library
using namespace std;

//User Libraries

//Global Constants, no Global Variables are allowed
//Math/Physics/Conversions/Higher Dimensions - i.e. PI, e, etc...

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Set the random number seed
    
    //Declare Variables
    int num_books,//number of books bought
           points;//points earned
    
    
    //Initialize or input i.e. set variable values
    cout<<"Book Worm Points"<<endl;
    cout<<"Input the number of books purchased this month."<<endl;
    cin>>num_books;
	points = 0;
    
    //Map inputs -> outputs
  points = num_books == 0? 4:
           num_books == 1? 5:
           num_books == 2? 15:
           num_books == 3? 30: 60;
    
    //Display the outputs
    cout<<"Books purchased = "<<setw(2)<<num_books<<endl;
    cout<<"Points earned   = "<<setw(2)<<points;
    //Exit stage right or left!
    return 0;
}