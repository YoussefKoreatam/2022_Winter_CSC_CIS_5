/* 
 * File:   main.cpp
 * Author: Youssef Koreatam
 * Created on January 19, 2022, 10:40 AM
 * Purpose:  Rock-Paper-Scissors
 */

//System Level Libraries
#include <iostream>  //Input-Output Library
#include <cstdlib>   //Random Function
#include <ctime>     //Time to set the seed
#include <cctype>
using namespace std;

//User Defined Libraries

//Global Constants, not Global Variables
//These are recognized constants from the sciences
//Physics/Chemistry/Engineering and Conversions between
//systems of units!

//Function Prototypes

//Execution begins here!
int main(int argc, char** argv) {
    //Initialize Random Seed once here!
    srand(static_cast<unsigned int>(time(0)));
    
    //Declare Variables
    char ply1,ply2;//The 2 players playing RoShamBo
    
    //Initialize Variables
    do{
        ply1=rand()%4+80;//[P,Q,R,S]
    }while(ply1=='Q');
    do{
        ply2=rand()%4+80;//[P,Q,R,S]
    }while(ply2=='Q');
    
    //Map the inputs/known to the outputs
    cout << "Rock Paper Scissors Game" << endl;
    cout << "Input Player 1 and Player 2 Choices" << endl;
    cin >> ply1 >> ply2;
    ply1 = tolower(ply1);
    ply2 = tolower(ply2);
    if(ply1==ply2){
        cout << "This is Tie!";
    }else if(ply1=='r'){
        if(ply2=='s')cout << "Rock" << " breaks " << "scissors.";
        if(ply2=='p')cout << "Paper"<<" covers "<< "rock.";
    }else if(ply1=='p'){
        if(ply2=='r')cout << "Paper" << " covers " << "rock.";
        if(ply2=='s')cout << "Scissors" << " cuts " << "paper.";
    }else if(ply1=='s'){
        if(ply2=='p')cout << "Scissors" << " cuts " << "paper.";
        if(ply2=='r')cout << "Rock" << " breaks " << "scissors.";
    }
    
    //Display the outputs
    
    //Exit the program
    return 0;
}